
extern SEXP hyperfunEvalEnv;
