# hyperfun
R package interface to [HyperFun](https://hyperfun.org/)

For more information see the [Constructive Solid Geometry: The 'hyperfun' Package](https://www.stat.auckland.ac.nz/~paul/Talks/NZSA2022/) presentation slides.
