
library(hyperfun)

## yz plane
hfR(function(xyz) xyz[1])

